package net.javaguide.springbootrestfulwebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestfulwebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestfulwebservicesApplication.class, args);
	}

}
